//
//  AppDelegate.h
//  iOSInTest
//
//  Created by Livesxu on 2020/6/15.
//  Copyright © 2020 Livesxu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Flutter/Flutter.h>

@interface AppDelegate : FlutterAppDelegate <UIApplicationDelegate>

@property (nonatomic, strong) FlutterEngine *flutterEngine;

@end

