//
//  AppDelegate.m
//  iOSInTest
//
//  Created by Livesxu on 2020/6/15.
//  Copyright © 2020 Livesxu. All rights reserved.
//

#import "AppDelegate.h"

#import <FlutterPluginRegistrant/GeneratedPluginRegistrant.h>

@interface AppDelegate ()<FlutterStreamHandler>

@property (nonatomic, strong) FlutterMethodChannel *methodChannel;

@property (nonatomic, strong) FlutterEventChannel *eventChannel;

@property (nonatomic,   copy) FlutterEventSink eventSink;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    self.flutterEngine = [[FlutterEngine alloc] initWithName:@"engine"];
    // Runs the default Dart entrypoint with a default Flutter route.
    [self.flutterEngine run];
    // Used to connect plugins (only if you have plugins with iOS platform code).
    [GeneratedPluginRegistrant registerWithRegistry:self.flutterEngine];
    
    __weak typeof(self) weakSelf = self;
    self.methodChannel = [FlutterMethodChannel methodChannelWithName:@"channel_1" binaryMessenger:self.flutterEngine.binaryMessenger];
    [self.methodChannel setMethodCallHandler:^(FlutterMethodCall * _Nonnull call, FlutterResult  _Nonnull result) {
        if ([call.method isEqual:@"method_1"]) {
            NSDictionary *dic = call.arguments;
            NSString *string = [dic valueForKey:@"count"];
            NSLog(@"%@",string);
            
            weakSelf.eventSink([NSString stringWithFormat:@"%@%@",@"count",string]);
        }
    }];
    
    self.eventChannel = [FlutterEventChannel eventChannelWithName:@"event_1" binaryMessenger:self.flutterEngine.binaryMessenger];
    
    [self.eventChannel setStreamHandler:self];
    
    return YES;
}

- (FlutterError* _Nullable)onListenWithArguments:(id _Nullable)arguments
                                       eventSink:(FlutterEventSink)events; {
    
    self.eventSink = events;
    
    return nil;
}

- (FlutterError* _Nullable)onCancelWithArguments:(id _Nullable)arguments; {
    
    return nil;
}


#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
