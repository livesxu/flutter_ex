//
//  ViewController.m
//  iOSInTest
//
//  Created by Livesxu on 2020/6/15.
//  Copyright © 2020 Livesxu. All rights reserved.
//

#import "ViewController.h"
#import <Flutter/Flutter.h>
#import "AppDelegate.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button addTarget:self
               action:@selector(showFlutter)
     forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"Show Flutter!" forState:UIControlStateNormal];
    button.backgroundColor = UIColor.blueColor;
    button.frame = CGRectMake(80.0, 210.0, 160.0, 40.0);
    [self.view addSubview:button];
}

- (void)showFlutter {
    
    //进入到默认flutter - main 页面
//    FlutterEngine *flutterEngine =
//        ((AppDelegate *)UIApplication.sharedApplication.delegate).flutterEngine;
//    FlutterViewController *flutterViewController =
//        [[FlutterViewController alloc] initWithEngine:flutterEngine nibName:nil bundle:nil];
//    [self presentViewController:flutterViewController animated:YES completion:nil];
    
    //进入到flutter - 指定route页面 - 不能创建engine,如果要获取engine从 flutterViewController.engine
    FlutterViewController *flutterViewController = [[FlutterViewController alloc]initWithProject:[[FlutterDartProject alloc]init] nibName:nil bundle:nil];
    [flutterViewController setInitialRoute:@"123"];
    [self presentViewController:flutterViewController animated:YES completion:nil];
    

    //进入到指定方法页面 - example：test
//    FlutterEngine *flutterEngine = [[FlutterEngine alloc] initWithName:@"engine1"];;
//    [flutterEngine runWithEntrypoint:@"test" libraryURI:nil];
//    FlutterViewController *flutterViewController =
//        [[FlutterViewController alloc] initWithEngine:flutterEngine nibName:nil bundle:nil];
//    [self presentViewController:flutterViewController animated:YES completion:nil];
}


@end
